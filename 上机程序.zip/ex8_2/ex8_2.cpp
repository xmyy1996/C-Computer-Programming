# include<iostream.h>
# include<iomanip.h>
void main()
{
	int a[5] = {1, 2, 3, 4, 5}, i;
	int *p;
	p = a;
	for(i = 0; i < 5; i++)
	{
		cout<<setw(3)<<a[i];
	}
	cout<<'\n';
	for(i = 0; i < 5; i++)
	{
		cout<<setw(3)<<*(a + i);
	}
	cout<<'\n';
	for(i = 0; i < 5; i++)
	{
		cout<<setw(3)<<*(p + i);
	}
	cout<<'\n';
	for(i = 0; i < 5; i++)
	{
		cout<<setw(3)<<p[i];
	}
	cout<<'\n';
	for(; p < a+5; p++)
	{
		cout<<setw(3)<<*p;
	}
	cout<<'\n';
}