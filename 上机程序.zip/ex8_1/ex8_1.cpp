# include<iostream.h>
void main()
{
	int a, b, c;
	int *p, *q, *t;
	p = &a;
	q = &b;
	t = &c;
	cin>>a>>b;
	*t = a + b;
	cout<<&a<<","<<&b<<","<<p<<","<<q<<endl;
	cout<<&p<<","<<&q<<endl;
	cout<<a<<","<<b<<","<<*p<<","<<*q<<endl;
	cout<<c<<","<<*t<<endl;
}