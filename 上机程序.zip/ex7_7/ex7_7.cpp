# include<iostream.h>
# include "string"
void main()
{
	char a[][8] = {"SQL", "Foxpro", "Unix", "ASP"};
	char str[8];
	int i, k, j;
	cout<<" ����ǰ�ַ���:"<<endl;
	for(i = 0; i <= 3; i++)
	{
		cout<<a[i]<<endl;
	}
	for(i = 0; i <= 2; i++)
	{
		k = i;
		for(j = i + 1; j <= 3; j++)
		{
			if(strcmp(a[k], a[j]) > 0)
			{
				k = j;
			}
		}
		if(k != i)
		{
			strcpy(str, a[k]);
			strcpy(a[k], a[i]);
			strcpy(a[i], str);
		}
	}
	cout<<" ������ַ���:"<<endl;
	for(i = 0; i <= 3; i++)
	{
		cout<<a[i]<<endl;
	}
}