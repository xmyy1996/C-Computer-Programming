# include<iostream.h>
# include<string>
# define N 15
void fun(char *);
void main()
{
	char a[N];
	gets(a);
	fun(a);
	for(int i = 0; i < N; i++)
	{
		if(a[i] == '\0')
		{
			cout<<i<<endl;
			break;
		}
	}
}
void fun(char *p)
{
	int i, j;
	for(i = 0; ; i++)
	{
		if(*(p+i) != '\0')
		{
			if(*(p+i) == ' ')
			{
				j = i;
				do
				{
					*(p+j) = *(p+j+1);
					j++;
				}while(*(p+j) != '\0');
			}
		}
		else
		{
			break;
		}
	}
	puts(p);
	/*
	char t;
	int i, j;
	for(j = 0; j < N; j++)
	{
		for(i = 0; i < N; i++)
		{
			if(*(p+i) == ' ')
			{
				t = *(p+i);
				*(p+i) = *(p+i+1);
				*(p+i+1) = t;
			}
			if(*(p+i+1) == '\0')
			{
				break;
			}
		}
	}*/
}