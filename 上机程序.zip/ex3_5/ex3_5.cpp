# include <iostream.h>
# include <iomanip.h>

void main()
{
	cout<<10.0/5<<endl;
	cout<<setiosflags(ios::showpoint)
		<<10.0/5<<endl;

}