# include<iostream.h>
# include<string>
# define N 10
int f(char *);
void main()
{
	char a[N];
	gets(a);
	if(f(a))
	{
		cout<<"YES!"<<endl;
	}
	else
	{
		cout<<"NO!"<<endl;
	}
}
int f(char *x)
{
	int i, j = 0, n;
	for(i = 0; ; i++)
	{
		if(*(x+i) == '\0')
		{
			break;
		}
	}
	n = i;
	for(i = 0; i < n/2; i++)
	{
		if(*(x+i) == *(x+n-i-1))
		{
			j++;
		}
	}
	if(j == n/2)
	{
		return 1;
	}
	else
	{
		return 0;

	}
}