# include<iostream.h>
# include<math.h>
# define N 0.000001
float fun();
void main()
{
	cout<<"cos(x) - x = 0��һ��ʵ������:"<<fun()<<endl;
}
float fun()
{
	double x1 = 0, x0;
	do
	{
		x0 = x1;
		x1 = cos(x0);
	}while(fabs(x0-x1) >= N);
	return x1;
}