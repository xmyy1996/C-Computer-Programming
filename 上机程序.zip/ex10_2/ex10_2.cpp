# include<iostream.h>
# include<iomanip.h>
# include<conio.h>
# include<string.h>
# include<stdio.h>
union condition
{
	int score[3];
	char situation[80];
};
struct person
{
	char name[20];
	char num[10];
	char kind;
	union condition state;
}personnel[4];
void main()
{
	int i, j;
	for(i = 0; i < 2; i++)
	{
		puts("Enter name: ");
		gets(personnel[i].name);
		puts("Enter num: ");
		gets(personnel[i].num);
		puts("Enter kind: ");
		personnel[i].kind = getchar();
		getchar();
		if(personnel[i].kind == 't')
		{ 
			puts("Enter situation: ");
			gets(personnel[i].state.situation);
		}
		else
		{
			for(j = 0; j < 3; j++)
			{
				cin>>personnel[i].state.score[j];
				fflush(stdin);
			}
			
		}
	}
	for(i = 0; i < 2; i++)
		{
			puts(personnel[i].name);
			puts(personnel[i].num);
			cout<<personnel[i].kind<<endl;
			if(personnel[i].kind == 't')
			{
				puts(personnel[i].state.situation);
			}
			else
			{
				for(j = 0; j < 3; j++)
				{
					cout<<setw(5)<<personnel[i].state.score[j]<<endl;
				}
			}
		}
}