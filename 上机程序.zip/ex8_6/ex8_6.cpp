# include<iostream.h>
# include"string"
void main()
{
	int k = 0;
	char a[80], b[80], c[80] = {'\0'}, *p, *q;
	p = a;
	q = b;
	gets(a);
	gets(b);
	while(a[k] != '\0' && b[k] != '\0')
	{
		if(a[k] > b[k])
		{
			c[k] = *p;
		}
		else
		{
			c[k] = *q;
		}
		p++;
		q++;
		k++;
	}
	if(*p != '\0')
	{
		strcat(c, p);
	}
	else
	{
		strcat(c, q);
	}
	cout<<"array c:"<<c<<endl;
}
