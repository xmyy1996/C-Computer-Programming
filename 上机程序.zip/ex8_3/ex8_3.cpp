# include<iostream.h>
# include<iomanip.h>
void main()
{
	int a[2][3] = {{0, 1, 2}, {3, 4, 5}};
	int k, j, *p;
	for(j = 0; j < 2; j++)
	{
		for(k = 0; k < 3; k++)
		{
			cout<<setw(5)<<*(a[j] + k);
		}
		cout<<'\n';
	}
	cout<<'\n';
	for(j = 0; j < 2; j++)
	{
		for(k = 0; k < 3; k++)
		{
			cout<<setw(5)<<*(*(a + j) + k);
		}
		cout<<'\n';
	}
	cout<<'\n';
	p = a[0];
	for(j = 0; j < 2; j++)
	{
		for(k = 0; k < 3; k++)
		{
			cout<<setw(5)<<*(p++);
		}
		cout<<'\n';
	}
}