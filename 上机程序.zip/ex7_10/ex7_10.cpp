# include<iostream.h>
void fun(int, char *);
void main()
{
	int m;
	char s[99];
	cout<<"Enter string:";
	cin>>s;
	cout<<"Enter m:";
	cin>>m;
	fun(m, s);
//	n = fun(m, s);
/*	for(int i = 0; i <= n-1; i++)
	{
		cout<<'s'<<i<<" = "<<s[i]<<endl;
	}*/
}
void fun(int m, char st[])
{
	int i, j, n;
	for(i = 0; ; i++)
	{
		if(st[i] == '\0')
		{
			break;
		}
	}
	n = i;
	j = n;
 	for(i = 0; i <= m-1; i++)
	{
		st[j] = st[i];
		j++;
	}
	j = m;
	for(i = 0; i <= n-m-1; i++)
	{
		st[i] = st[j];
		j++;
	}
	j = n;
	for(i = 1; i <= n-1; i++)
	{
		st[i] = st[j];
		j++;
	}
	for(i = 0; i <= 5; i++)
	{
		cout<<'s'<<i<<" = "<<st[i]<<endl;
	}
}