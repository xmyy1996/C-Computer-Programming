# include <iostream.h>
void main()
{
	int x, y, t;
	x = 10;
	t = x && x > 10;
	cout<<t<<endl;
	
	x = 2;
	y = 0;
	t = x || (y = y + 1);	//�ж�xΪ���ֹͣ����y = y + 1
	cout<<t<<endl;
	cout<<y<<endl;
}