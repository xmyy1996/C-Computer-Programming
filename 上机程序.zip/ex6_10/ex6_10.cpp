# include<iostream.h>
float fun(double);
void main()
{
	double h;
	cout<<"Enter h:";
	cin>>h;
	cout<<"h = "<<fun(h);
}
float fun(double h)
{
	h = h * 1000;
	int i = h;
	if(i % 10 >= 5)
	{
		i = (i / 10) + 1;
	}
	else
	{
		i = i / 10;
	}
	h = double(i) / 100;
	return h;
}