# include <iostream.h>
void main()
{
	int a, b, c;
	cin>>a>>b>>c;
	switch (a)
	{
		case 1:
		case 2:
		case 3: cout<<a<<"+"<<c<<"="<<b + c<<endl;
		case 4: cout<<a<<"-"<<c<<"="<<b - c<<endl;
		case 5: cout<<a<<"*"<<c<<"="<<b * c<<endl;
		case 6: cout<<a<<"/"<<c<<"="<<b / c<<endl;
		default: cout<<"a��ֵ����ȷ!"<<endl;
	}
}