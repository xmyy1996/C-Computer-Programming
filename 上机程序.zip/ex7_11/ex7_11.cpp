# include<iostream.h>
int sum(int, int, char num[][18]);
int tf(int, int, char num[][18]);
void main()
{
	int i, j, m, n, mod;
	char num[10][18];
	cout<<"����������֤�������: ";
	cin>>n;
	cout<<"����������֤����: "<<endl;
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < 18; j++)
		{
			cin>>num[i][j];
		}
	}
	cout<<'\n';
	j = 0;
	for(i = 0; i < n; i++)
	{
		mod = sum(n, i, num) % 11;
		if(tf(mod, i, num))
		{
			j = j + 1;
		}
		else
		{
			for(m = 0; m < 18; m++)
			{
				cout<<num[i][m];
			}
			cout<<'\n';
		}
	}
	if(j == n)
	{
		cout<<"All passed"<<endl;
	}
	
}
int sum(int n, int m, char num1[][18])
{
	int a[17] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
	int s = 0;
	int i;
	for(i = 0; i < 17; i++)
	{
			s = s + a[i] * (num1[m][i]-48);
	}
	return s;
}
int tf(int mod, int i, char num2[][18])
{	
	char a1[12] = "10X98765432";
	char t;
	t = a1[mod];
	if(num2[i][17] == t)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}