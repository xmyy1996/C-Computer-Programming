# include <iostream.h>
# include <iomanip.h>

void main()
{
	cout<<10<<" "<<-20<<endl;
	cout<<setiosflags(ios::showpos)
		<<10<<" "<<-20<<endl;
}