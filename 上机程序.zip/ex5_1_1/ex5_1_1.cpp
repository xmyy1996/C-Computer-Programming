# include<iostream.h>

void main()
{
	int n, s;
	n = 0;
	s = 0;
	do
	{
		s += n;
		n++;
	}while(n <= 100);
	cout<<"1 + 2+ 3 +��+ 100 = "<<s<<endl;
}