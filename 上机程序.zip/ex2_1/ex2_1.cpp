# include<iostream.h>

void main()
{
	cout<<"Where" 
	<<"are "
	<<"you "
	<<"come "
	<<"from?"
	<<endl;
	cout<<"I am a teacher!"<<endl;
	cout<<"You are a astudent."<<endl;
	cout<<"We are learning C program language!"<<endl;
}