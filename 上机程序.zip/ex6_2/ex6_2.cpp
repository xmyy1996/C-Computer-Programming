# include<iostream.h>
void main()
{
	int sum(int x, int y);
	int a, b, c;
	a = 3, b = 4;
	c = sum(a, b);
	cout<<a<<'+'<<b<<'='<<c<<endl;
}
int sum(int x, int y)
{
	int z;
	z = x + y;
	return(z);
}