# include<iostream.h>
void main()
{
	int max, i, j, k;
	int a[] = {5, 8, 4, 7, 1, 2, 11, 10};
	max = a[0], k = 0;
	for(i = 1; i <= 7; i++)
	{
		if(max < a[i])
		{
			max = a[i];
			k = i;
		}
	}
	cout<<"position is "<<k + 1<<endl;
	cout<<"value is "<<max<<endl;
}