# include<iostream.h>
void main()
{
	char a[6] = "BASIC";
	cout<<a<<endl;
	cout<<a[0]<<","<<a[1]<<","<<a[2]<<endl;
}