# include<iostream.h>
# define N 10
int fun(int *, int, int *);
void main()
{
	int a[N], i, t, *k, sub, *s;
	k = &sub;
	cout<<"��������Ԫ�ظ���:";
	cin>>t;
	s = a;
	cout<<"��������:";
	for(i = 0; i < t; i++)
	{
		cin>>a[i];
	}
	cout<<*k<<','<<fun(s, t, k)<<endl;
}
int fun(int *s, int t, int *k)
{
	int i, temp;
	temp = *s;
	for(i = 0; i < t; i++)
	{
		if(temp < *s)
		{
			temp = *s;
			*k = i;
		}
		s++;
	}
	return temp;
}