# include<iostream.h>
# include<iomanip.h>
# include"string.h"
typedef struct student
{
	char name[10];
	int age;
	int score;
};
void main()
{
	struct student stu;
	strcpy(stu.name, "Gao Haong");
	stu.age = 20;
	stu.score = 90;
	cout<<setw(10)<<stu.name<<','<<setw(5)<<stu.age<<','<<setw(5)<<stu.score<<endl;
}
