/*# include <iostream.h>
# include <iomanip.h>

void main()
{
	float x, y;
	cin>>x;
	if (x <= -10)
	{
		y = 2 * x;
	}
	else
	{
		if (x <= 0)
		{
			y = 2 + x;
		}
		else
		{
			if (x <= 10)
			{
				y = x - 2;
			}
			else
			{
				y = x / 10;
			}
		}
	}
	cout<<setiosflags(ios::showpoint)<<"x = "<<x<<"y = "<<y<<endl;
}

# include <iostream.h>

void main()
{
	float x;
	char y;
	cin>>x;
	if (x < 60)
	{
		y = 'E';
	}
	else
	{
		if (x < 70)
		{
			y = 'D';
		}
		else
		{
			if (x < 80)
			{
				y = 'C';
			}
			else
			{
				if (x < 90)
				{
					y = 'B';
				}
				else
				{
					y = 'A';
				}
			}
		}
	}
	cout<<y<<endl;
}
*/

# include <iostream.h>

void main()
{
	float x;
	int i, y;
	cin>>x;
	y = x / 10;
	if (y <= 5)
	{
		i = 5;
	}
	switch (i)
	{
		case 5: cout<<"E"<<endl;
			break;
		case 6:cout<<"D"<<endl;
			break;
		case 7:cout<<"C"<<endl;
			break;
		case 8:cout<<"B"<<endl;
			break;
		case 9:cout<<"A"<<endl;
			break;
		default:cout<<"A"<<endl;
	}
}
