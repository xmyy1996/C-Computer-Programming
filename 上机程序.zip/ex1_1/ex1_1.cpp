# include<iostream.h>
void main()
{
	int a,b,c;
	a = 10, b = 5;
	c = a + b;
	cout<<"c="<<c<<endl;
}