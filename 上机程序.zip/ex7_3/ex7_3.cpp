# include<iostream.h>
# include<iomanip.h>
void main()
{
	int data, temp, k;
	int a[9] = {50, 25, 15, 10, 8, 4, 2, -10};
	cout<<"Enter a data:";
	cin>>data;
	a[8] = data;
	for(k = 8; k >= 1; k--)
	{
		if(a[k] > a[k-1])
		{
			temp = a[k];
			a[k] = a[k-1];
			a[k-1] = temp;
		}
		else
		{
			break;
		}
	}
	for(k = 0; k <= 8; k++)
	{
		cout<<setw(5)<<a[k];
	}
	cout<<"\n";
}