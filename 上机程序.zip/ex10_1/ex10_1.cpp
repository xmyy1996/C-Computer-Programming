# include<iostream.h>
void main()
{
	union data
	{
		int a, b;
		struct
		{
			int c, d;
		}tt;
	}e = {8};
	e.b = e.a + 3;
	e.tt.c = e.a + e.b;
	e.tt.d = e.a * e.b;
	cout<<e.tt.c<<", "<<e.tt.d<<endl;
}