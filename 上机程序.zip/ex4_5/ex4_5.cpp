# include <iostream.h>
# include <iomanip.h>

void main()
{
	float x, y;
	int grade = 0, flag = 0;
	cin>>x;
	if (x > -5 && x < 0)
	{
		grade = 1;
	}
	if (x == 0)
	{
		grade = 2;
	}
	if (x > 0 && x < 8)
	{
		grade = 3;
	}
	switch (grade)
	{
		case 1: y = x - 1;
			break;
		case 2: y = x;
			break;
		case 3: y = x + 1;
			break;
		default: cout<<"x��ֵ������Χ"<<endl;
			flag = 1;
	}
	if (! flag)
	{
		cout<<setiosflags(ios::showpoint)<<"x = "<<x<<","<<"y = "<<y<<endl;s
	}
}