# include<iostream.h>
# include<iomanip.h>
void main()
{
	int a[5][5] = {{1, 2, 3, 4, 5}, {6, 7, 8, 9, 10}, {11, 12, 13, 14, 15}, {16, 17, 18, 19, 20}, {21, 22, 23, 24, 25}};
	int i, j;
	cout<<"��ӡ�����ά�����ֵ:"<<endl;
	for(i = 0; i < 5; i++)
	{
		for(j = 0; j < 5; j++)
		{
			cout<<setw(5)<<a[i][j];
		}
		cout<<"\n";
	}
	cout<<"������Խ����ϵ�ֵ:"<<endl;
	for(i = 0; i < 5; i++)
	{
		for(j = 0; j < 5; j++)
		{
			if(i == j)
			{
				cout<<setw(3)<<a[i][j];
				break;
			}
		}
		cout<<"\n";
	}
}