# include<iostream.h>

int min(int m, int n)
{
	if (m >= n)
	{
		return n;
	}
	else
	{
		return m;
	}
}
int max(int m, int n)
{
	if (m >= n)
	{
		return m;
	}
	else
	{
		return n;
	}
}		//����һ

void main()
{
	int a, b, c, d;
	cin>>a>>b;
	a >= b? c = b: c = a;
	a >= b? d = a: d = b;
	cout<<"c = "<<c<<endl
		<<"d = "<<d<<endl;		//������
	cout<<"c = "<<min(a, b)<<endl
		<<"d = "<<max(a, b)<<endl;
}

