# include<iostream.h>
float fun(int);

void main()
{
	int n;
	cout<<"Enter n:";
	cin>>n;
	cout<<"1+1/(1+2)+1/(1+2+3)+��+1/(1+2+3+��n) = "<<fun(n)<<endl;
}
float fun(int n)
{
	int i, j = 0;
	float s = 0;
	for(i = 1; i <= n; i++)
	{
		j = j + i;
		s = s + 1.0/j;
	}
	return s;
}