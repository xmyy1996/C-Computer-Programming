# include<iostream.h>
float average(struct student sco[]);
void sort_put(struct student sco[]);
struct student
{
	int score;
};
void main()
{
	struct student sco[5];
	int i;
	cout<<"Enter score:";
	for(i = 0; i < 5; i++)
	{
		cin>>sco[i].score;	
	}
	cout<<"The average score is:"<<average(sco)<<endl;
	sort_put(sco);
}
float average(struct student score[])
{
	int i, sum;
	float ave;
	sum = 0;
	for(i = 0; i < 5; i++)
	{
		sum = sum + score[i].score;
	}
	ave = sum / 5.0;
	return ave;
}
void sort_put(struct student score[])
{
	int i, j;
	struct student temp;
	for(i = 0; i < 4; i++)
	{
		for(j = i+1; j < 5; j++)
		{
			if(score[i].score > score[j].score)
			{
				temp.score = score[i].score;
				score[i].score = score[j].score;
				score[j].score = temp.score;
			}
		}
	}
	for(i = 0; i < 5; i++)
	{
		cout<<score[i].score<<' ';
	}
	cout<<'\n';
}
