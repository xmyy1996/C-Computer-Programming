# include<iostream.h>
# include<iomanip.h>
# define N 9
int fun(int a[], int n)
{
	int i, j;
	j = 0;
	for(i = 0; i < n; i++)
	{
		if(a[i] % 2 == 0)
		{
			a[j] = a[i];
			j++;
		}
	}
	return j;
}
void main()
{
	int b[N] = {9, 1, 4, 2, 3, 6, 5, 8, 7}, i, n;
	cout<<"\nThe original data:"<<endl;
	for(i = 0; i < N; i++)
	{
		cout<<setw(4)<<b[i];
	}
	cout<<"\n";
	n = fun(b, 9);
	cout<<"\nThe number of even: "<<n<<endl;
	cout<<"\nThe even: "<<endl;
	for(i = 0; i < n; i++)
	{
		cout<<setw(4)<<b[i];
	}
	cout<<"\n";
}