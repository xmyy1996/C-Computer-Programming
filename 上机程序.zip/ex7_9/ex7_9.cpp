# include<iostream.h>
void main()
{
	int a[][6] = {{1, 3, 5, 7, 9}, {2, 9, 9, 9, 4}, {6, 9, 9, 9, 8}, {1, 3, 5, 7, 0}};
	int sum = 0;
	int i, j;
	for(i = 0; i <= 3; i++)
	{
		for(j = 0; j <= 4; j++)
		{
			if(i == 0 || i == 3)
			{
				sum = sum + a[i][j];
			}
			else if(j == 0 || j == 4)
			{
				sum = sum + a[i][j];
			}
		}
	}
	cout<<sum<<endl;

}