# include<iostream.h>
void main()
{
	int i;
	int n, a[8];
	cin>>n;
	cout<<"��8λ:"<<(n>>8)<<endl;
	for(i = 7; i >= 0; i--)
	{
		if(n & 1)
		{
			a[i] = 1;
		}
		else
		{
			a[i] = 0;
		}
		n = n >> 1;
	}
	cout<<"��8λ:";
	for(i = 0; i < 8; i++)
	{
		cout<<a[i];
	}
	cout<<'\n';
}
