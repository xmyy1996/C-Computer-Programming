# include<iostream.h>
void f1();
void f2();
int x = 3;
void main()
{
	auto int x = 4;
	cout<<"(1)x = "<<x<<endl;
	f1();
	f2();
	cout<<"(4)x = "<<x<<endl;
}
void f1()
{
	x += 10;
	cout<<"(2)x = "<<x<<endl;
}
void f2()
{
	x += 10;
	cout<<"(3)x = "<<x<<endl;
}
