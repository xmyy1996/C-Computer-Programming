# include <iostream.h>

void main()
{
	int x, y;
	char ch1, ch2, ch3;
	cin>>x>>y;
	cout<<"x = "<<x<<","<<"y = "<<y<<endl;
	cin>>ch1>>ch2>>ch3;
	cout<<"ch1 = "<<ch1<<","<<"ch2 = "<<ch2<<","<<"ch3 = "<<ch3<<endl;
	cout<<"ch1 = "<<(int)ch1<<","<<"ch2 = "<<(int)ch2<<","<<"ch3 = "<<(int)ch3<<endl;
}