# include <iostream.h>

void main()
{
	char i;
	cin>>i;
	if (i >= 0 && i <= 9)
	{
		cout<<i<<endl;
	}
	else
	{
		cout<<(int)i<<endl;
	}
}

