# include<iostream.h>
# include<iomanip.h>
struct student
{
	char name[10];
	int age;
	int score;
};
void main()
{
	int i;
	stu[3] = {{"Lin Dan", 28, 100}, {"Feng Kun", 25, 92}, {"Yang Qin", 27, 60}};
	for(i = 0; i < 3; i++)
	{
		cout<<setw(10)<<stu[i].name<<','<<setw(5)<<stu[i].age<<','<<setw(5)<<stu[i].score<<endl;
	};
}