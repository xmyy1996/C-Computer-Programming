# include <iostream.h>
# include <iomanip.h>

void main()
{
	float r, l, s, pi;
	cin>>r;
	pi = 3.14159;
	l = 2 * pi * r;
	s = r * r * pi;
	cout<<setiosflags(ios::fixed)<<setprecision(4)<<"l = "<<setw(8)<<l<<endl;
	cout<<setiosflags(ios::fixed)<<setprecision(4)<<"s = "<<setw(8)<<s<<endl;
}