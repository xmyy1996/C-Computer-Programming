# include<iostream.h>
void main()
{
	char a[] = "CHINA";
	char *p;
	p = a;
	cout<<*p<<","<<*(p + 2)<<endl;
}