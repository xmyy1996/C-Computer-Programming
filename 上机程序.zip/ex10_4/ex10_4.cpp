# include<iostream.h>
void main()
{
	int c, d, e;
	int a = 6, b = 12;
	c = a & b;
	d = a | b;
	e = a ^ b;
	cout<<a<<"&"<<b<<"="<<c<<endl;
	cout<<a<<"|"<<b<<"="<<d<<endl;
	cout<<a<<"^"<<b<<"="<<e<<endl;
}