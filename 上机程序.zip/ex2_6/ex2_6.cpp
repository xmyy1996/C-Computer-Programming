# include<iostream.h>

void main()
{
	int a, c;
	float b;
	a = 14, b= 144,345;
	c = a + (int)b;
	cout<<a<<endl
		<<b<<endl
		<<c<<endl;

}