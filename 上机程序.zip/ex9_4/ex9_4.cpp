# include<iostream.h>
# include<stdlib.h>
# define N 8
typedef struct list
{
	int data;
	struct list *next;
}SLIST;
SLIST *creatlist(int *);
void outlist(SLIST *);
void main()
{
	SLIST *head;
	int a[N] = {12, 87, 45, 32, 91, 16, 20, 48};
	head = creatlist(a);
	outlist(head);
}
SLIST *creatlist(int a[])
{
	SLIST *h, *p, *q;
	int i;
	h = p = (SLIST *)malloc(sizeof(SLIST));
	for(i = 0; i < N; i++)
	{
		q = (SLIST *)malloc(sizeof(SLIST));
		q->data = a[i];
		p->next = q;
		p = p->next;
	}
	p->next = 0;
	return h;
}
void outlist(SLIST *h)
{
	SLIST *p;
	p = h->next;
	if(p == NULL)
	{
		cout<<"The list is NULL!"<<endl;
	}
	else
	{
		cout<<"\nHead ";
		do
		{
			cout<<"-> "<<p->data;
			p = p->next;
		}while(p != NULL);
		cout<<"->End"<<endl;
	}
}