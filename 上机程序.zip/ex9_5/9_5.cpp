# include<iostream.h>
# include<stdlib.h>

typedef struct stu
{
	long no;
	int score;
	struct stu *next;
}STU;
STU *creatlist(int);
void outlist(STU *);
void insert(STU *);
void sort(STU *);
void main()
{
	STU *head;
	int n, no, score;
	cin>>n;
	cout<<'\n';
	head = creatlist(n);
	outlist(head);
	cout<<'\n';
	insert(head);
	outlist(head);
	cout<<'\n';
	sort(head);
	outlist(head);
	cout<<'\n';
}
STU *creatlist(int n)
{
	int i;
	STU *p, *q, *h;
	h = p = (STU *)malloc(sizeof(STU));
	for(i = 1; i <= n; i++)
	{
		q = (STU *)malloc(sizeof(STU));
		cin>>q->no>>q->score;
		p->next = q;
		p = q;
	}
	p->next = 0;
	cout<<'\n';
	return h;
}
void outlist(STU *h)
{
	STU *p;
	p = h->next;
	while(p != NULL)
	{
		cout<<p->no<<' '<<p->score<<endl;
		p = p->next;
	}
}
void insert(STU *h)
{
	long no, int score;
	cin>>no>>score;
	cout<<'\n';
	STU *p, *p1, *p2, *q;
	p = h->next;
	if(p->no > no)
	{
		p2 = h->next;
		q = (STU *)malloc(sizeof(STU));
		q->no = no;
		q->score = score;
		h->next = q;
		p = q;
		p->next = p2;
	}
	else if(p->next == 0)
	{
		q = (STU *)malloc(sizeof(STU));
		q->no = no;
		q->score = score;
		p->next = q;
		p = q;
		p->next = 0;
	}
	else
	{
		p1 = p->next;
		while(p1->no <= no)
		{
			if(p1->next == 0)
			{
				break;
			}
			p = p->next;
			p1 = p->next;
		}
		if(p1->no > no)
		{
			p2 = p->next;
			q = (STU *)malloc(sizeof(STU));
			q->no = no;
			q->score = score;
			p->next = q;
			p = q;
			p->next = p2;
		}
		else 
		{
			p = p->next;
			q = (STU *)malloc(sizeof(STU));
			q->no = no;
			q->score = score;
			p->next = q;
			p = q;
			p->next = 0;
		}
	}
}
void sort(STU *h)
{
	int i;
	long t1;
	int t2;
	STU *p1, *p2;
	p1 = h->next;
	p2 = p1->next;
	for(; p1->next != 0;)
	{
		for(i = 1; i != 0;)
		{

			if(p1->score > p2->score)
			{
				t1 = p1->no;
				p1->no = p2->no;
				p2->no = t1;
				t2 = p1->score;
				p1->score = p2->score;
				p2->score = t2;
			}
			if(p2->next == 0)
			{
				i = 0;
				continue;
			}
			p2 = p2->next;
		}
		p1 = p1->next;
		p2 = p1->next;
	}
}
