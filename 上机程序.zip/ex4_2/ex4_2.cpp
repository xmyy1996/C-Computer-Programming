/*
# include <iostream.h>

void main()
{
	int a, b;
	cin>>a>>b;
	if (a > b)
	{
		cout<<a<<endl;
	}
	else
	{
		cout<<b<<endl;
	}
}
*/
//�޸ĺ�
# include <iostream.h>

void main()
{
	int a, b, c;
	int max;
	cin>>a>>b>>c;
	if (a > b)
	{
		if (a > c)
		{
			max = a;
		}
		else
		{
			max = c;
		}
		
	}
	else
	{
		if (b > c)
		{
			max = b;
		}
		else
		{
			max = c;
		}
	}
	cout<<max<<endl;
}