# include<iostream.h>
# include<string>
# define N 10
void fun(char *);
void main()
{
	char a[N], *ss;
	gets(a);
	ss = a;
	fun(ss);
}
void fun(char *ss)
{
	int i;
	for(i = 0; ; i++)
	{
		if(*(ss + i) == '\0')
		{
			break;
		}
		if(i % 2 == 1)
		{
			if(*(ss+i) >= 'a' && *(ss+i) <= 'z')
			{
				*(ss+i) = *(ss+i) - 32;
			}
		}
	}
	puts(ss);
}