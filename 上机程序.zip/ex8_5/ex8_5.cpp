# include<iostream.h>
# include<iomanip.h>
void main()
{
	int a[6], i;
	int *p;
	for(i = 0; i < 6; i++)
	{
		cin>>a[i];
	}
	p = a;
	for(i = 0; i < 6; i++)
	{
		cout<<setw(3)<<*(p + i);
	}
	cout<<'\n';
}