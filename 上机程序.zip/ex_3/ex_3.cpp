# include<iostream.h>
# include<string>
# define N 15
void fun(char *);
void main()
{
	char a[N];
	gets(a);
	fun(a);
	for(int i = 0; i < N; i++)
	{
		if(a[i] == '\0')
		{
			cout<<i<<endl;
			break;
		}
	}
}
void fun(char a[])
{
	char p;
	int i, j;
	for(j = 0; j < N; j++)
	{
		for(i = 0; i < N; i++)
		{
			if(a[i] == ' ')
			{
				p = a[i];
				a[i] = a[i+1];
				a[i+1] = p;
			}
			if(a[i+1] == '\0')
			{
				break;
			}
		}
	}
	puts(a);
}