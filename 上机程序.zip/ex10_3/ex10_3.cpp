# include<iostream.h>
void main()
{
	enum colorname
	{
		red, yellow, blue, white, black
	};
	enum colorname color;
	for(color == red; color < black; color = (enum colorname)(color + 1))
	{
		switch (color)
		{
			case red:cout<<"red"<<endl;
				break;
			case yellow:cout<<"yellow"<<endl;
				break;
			case blue:cout<<"blue"<<endl;
				break;
			case white:cout<<"white"<<endl;
				break;
			case black:cout<<"black"<<endl;
				break;
		}
	}
}