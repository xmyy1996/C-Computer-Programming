# include<iostream.h>
# include<string.h>
void count(char a[])
{
	int sum1 = 0, sum2 = 0, sum3 = 0;
	int i;
	for(i = 0; a[i] != '\0'; i++)
	{
		if(a[i] >= 'a' && a[i] <= 'z' || a[i] >= 'A' && a[i] <= 'Z')
		{
			sum1++;
		}
		else if(a[i] >= '0' && a[i] <= '9')
		{
			sum2++;
		}
		else
		{
			sum3++;
		}
	}
	cout<<"sum1 = "<<sum1<<','<<"sum2 = "<<sum2<<','<<"sum3 = "<<sum3<<endl;
}
void main()
{
	char string[81];
	cout<<"input string: "<<endl;
	cin>>string;
	count(string);
}