# include<iostream.h>
void sort(int *, int *);
void main()
{
	int a, b, *pointer_1, *pointer_2;
	pointer_1 = &a;
	pointer_2 = &b;
	cout<<"input 2 data:";
	cin>>a>>b;
	sort(&a, &b);
	cout<<*pointer_1<<","<<*pointer_2<<endl;
}
void sort(int *p1, int *p2)
{
	int temp;
	temp = *p1;
	*p1 = *p2;
	*p2 = temp;
	cout<<*p1<<","<<*p2<<endl;
}