# include<iostream.h>
# include<iomanip.h>

void main()
{
	int a = 7, b = 2;
	float y1, y2;
	y1 = a / b;
	y2 = (float)a / b;
	cout<<"y1 = "<<y1<<endl
		<<"y2 = "<<y2<<endl;
	cout<<setiosflags(ios::fixed)<<setprecision(2)<<y2<<endl;
	cout.unsetf(ios::fixed);
}