# include<iostream.h>
enum mon
{
	Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Now, Dec
}month;
void main()
{
	float a[12];
	float sum = 0;
	for(month = Jan; month <= Dec; month = (enum mon)(month + 1))
	{
		switch(month)
		{
			case Jan: cout<<"Jan"<<endl;
				cin>>a[month];
				break;
			case Feb: cout<<"Feb"<<endl;
				cin>>a[month];
				break;
			case Mar: cout<<"Mar"<<endl;
				cin>>a[month];
				break;
			case Apr: cout<<"Apr"<<endl;
				cin>>a[month];
				break;
			case May: cout<<"May"<<endl;
				cin>>a[month];
				break;
			case Jun: cout<<"Jun"<<endl;
				cin>>a[month];
				break;
			case Jul: cout<<"Jul"<<endl;
				cin>>a[month];
				break;
			case Aug: cout<<"Aug"<<endl;
				cin>>a[month];
				break;
			case Sep: cout<<"Sep"<<endl;
				cin>>a[month];
				break;
			case Oct: cout<<"Oct"<<endl;
				cin>>a[month];
				break;
			case Now: cout<<"Now"<<endl;
				cin>>a[month];
				break;
			case Dec: cout<<"Dec"<<endl;
				cin>>a[month];
				break;
		}
		sum = sum + a[month];
	}
	cout<<"The salary of year is :"<<sum;
}