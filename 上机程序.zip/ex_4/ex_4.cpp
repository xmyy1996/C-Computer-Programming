# include<iostream.h>
void fun(int *);
void main()
{
	int a[3][3] = {{45, 75, 35}, {75, 25, 35}, {45, 55, 65}};
	fun(&a[0][0]);
}
void fun(int *p)
{
	
	cout<<*(p+2+3);
}