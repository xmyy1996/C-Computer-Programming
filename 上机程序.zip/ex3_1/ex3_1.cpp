# include <iostream.h>
# include <iomanip.h>

void main()
{
	int num1, num2, num3;
	float average;
	cout<<"Please input three numbers:";
	cin>>num1>>num2>>num3;
	average = (num1 + num2 + num3)/3.0;
	cout<<setiosflags(ios::fixed)<<setprecision(2)<<average<<endl;
}