# include <iostream.h>

void main()
{
	int a, b, t;
	cout<<"Enter a b:";
	cin>>a>>b;
	a = a + b;
	b = a - b;
	a = a - b;
	cout<<"a = "<<a<<","<<"b = "<<b<<endl;
}


